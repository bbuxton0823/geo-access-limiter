<?php
/**
 * The admin-specific functionality of the plugin.
 */
class Geo_Access_Limiter_Admin {

    /**
     * The plugin settings.
     *
     * @var array
     */
    private $settings;

    /**
     * Initialize the class.
     *
     * @param array $settings Plugin settings.
     */
    public function __construct($settings) {
        $this->settings = $settings;
        
        // Add admin scripts and styles
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_styles'));
    }

    /**
     * Enqueue admin styles
     */
    public function enqueue_admin_styles($hook) {
        // Only load on our settings page
        if ($hook != 'settings_page_geo-access-limiter') {
            return;
        }
        
        wp_enqueue_style(
            'geo-access-limiter-admin',
            GEO_ACCESS_LIMITER_URL . 'public/css/geo-access-limiter.css',
            array(),
            GEO_ACCESS_LIMITER_VERSION
        );
    }

    /**
     * Add the options page to the admin menu
     */
    public function add_plugin_admin_menu() {
        add_options_page(
            __('Geo Access Limiter Settings', 'geo-access-limiter'),
            __('Geo Access Limiter', 'geo-access-limiter'),
            'manage_options',
            'geo-access-limiter',
            array($this, 'display_plugin_admin_page')
        );
    }

    /**
     * Register settings for the admin page
     */
    public function register_settings() {
        register_setting(
            'geo_access_limiter_settings',
            'geo_access_limiter_settings',
            array($this, 'validate_settings')
        );

        // Add settings sections
        add_settings_section(
            'geo_access_limiter_general',
            __('General Settings', 'geo-access-limiter'),
            array($this, 'render_section_general'),
            'geo_access_limiter'
        );

        // Add settings fields
        add_settings_field(
            'api_key',
            __('API Key', 'geo-access-limiter'),
            array($this, 'render_field_api_key'),
            'geo_access_limiter',
            'geo_access_limiter_general'
        );

        add_settings_field(
            'allowed_locations',
            __('Allowed Locations', 'geo-access-limiter'),
            array($this, 'render_field_allowed_locations'),
            'geo_access_limiter',
            'geo_access_limiter_general'
        );

        add_settings_field(
            'restriction_message',
            __('Restriction Message', 'geo-access-limiter'),
            array($this, 'render_field_restriction_message'),
            'geo_access_limiter',
            'geo_access_limiter_general'
        );

        add_settings_field(
            'is_enabled',
            __('Enable Restriction', 'geo-access-limiter'),
            array($this, 'render_field_is_enabled'),
            'geo_access_limiter',
            'geo_access_limiter_general'
        );
    }

    /**
     * Render the admin page
     */
    public function display_plugin_admin_page() {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('geo_access_limiter_settings');
                do_settings_sections('geo_access_limiter');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    /**
     * Render the general section description
     */
    public function render_section_general() {
        echo '<div class="geo-access-settings-info">';
        echo '<p>' . __('Configure the Geo Access Limiter settings.', 'geo-access-limiter') . '</p>';
        echo '</div>';
    }

    /**
     * Render the API key field
     */
    public function render_field_api_key() {
        $api_key = isset($this->settings['api_key']) ? $this->settings['api_key'] : '';
        ?>
        <input type="text" name="geo_access_limiter_settings[api_key]" value="<?php echo esc_attr($api_key); ?>" class="regular-text geo-access-api-key-field">
        <p class="description"><?php _e('Enter your geolocation API key (like ipinfo.io)', 'geo-access-limiter'); ?></p>
        <?php
    }

    /**
     * Render the allowed locations field
     */
    public function render_field_allowed_locations() {
        $allowed_locations = isset($this->settings['allowed_locations']) ? $this->settings['allowed_locations'] : array();
        
        // Create a list of countries
        $countries = array(
            'US' => 'United States',
            'CA' => 'Canada',
            'GB' => 'United Kingdom',
            'AU' => 'Australia',
            'DE' => 'Germany',
            'FR' => 'France',
            'IT' => 'Italy',
            'ES' => 'Spain',
            'JP' => 'Japan',
            'CN' => 'China',
            'BR' => 'Brazil',
            'IN' => 'India',
            // Add more countries as needed
        );
        
        echo '<select name="geo_access_limiter_settings[allowed_locations][]" multiple="multiple" class="geo-access-country-select">';
        
        foreach ($countries as $code => $name) {
            $selected = in_array($code, $allowed_locations) ? 'selected="selected"' : '';
            echo '<option value="' . esc_attr($code) . '" ' . $selected . '>' . esc_html($name) . '</option>';
        }
        
        echo '</select>';
        echo '<p class="description">' . __('Select the countries where your site should be accessible. Hold Ctrl/Cmd to select multiple.', 'geo-access-limiter') . '</p>';
    }

    /**
     * Render the restriction message field
     */
    public function render_field_restriction_message() {
        $message = isset($this->settings['restriction_message']) ? $this->settings['restriction_message'] : 'Sorry, this site is not available in your region.';
        ?>
        <textarea name="geo_access_limiter_settings[restriction_message]" rows="3" class="large-text geo-access-message-field"><?php echo esc_textarea($message); ?></textarea>
        <p class="description"><?php _e('The message to display when access is denied.', 'geo-access-limiter'); ?></p>
        <?php
    }

    /**
     * Render the enabled field
     */
    public function render_field_is_enabled() {
        $is_enabled = isset($this->settings['is_enabled']) ? $this->settings['is_enabled'] : false;
        ?>
        <label>
            <input type="checkbox" name="geo_access_limiter_settings[is_enabled]" value="1" <?php checked($is_enabled, true); ?>>
            <?php _e('Enable geo-restriction', 'geo-access-limiter'); ?>
        </label>
        <p class="description"><?php _e('Check to enable the geo-restriction functionality.', 'geo-access-limiter'); ?></p>
        <?php
    }

    /**
     * Validate settings before saving
     *
     * @param array $input The settings array to validate
     * @return array Validated settings
     */
    public function validate_settings($input) {
        $output = array();
        
        // Validate API key
        $output['api_key'] = isset($input['api_key']) ? sanitize_text_field($input['api_key']) : '';
        
        // Validate allowed locations
        $output['allowed_locations'] = isset($input['allowed_locations']) && is_array($input['allowed_locations']) ? 
                                        array_map('sanitize_text_field', $input['allowed_locations']) : 
                                        array();
        
        // Validate restriction message
        $output['restriction_message'] = isset($input['restriction_message']) ? 
                                        sanitize_textarea_field($input['restriction_message']) : 
                                        'Sorry, this site is not available in your region.';
        
        // Validate is_enabled
        $output['is_enabled'] = isset($input['is_enabled']) ? (bool) $input['is_enabled'] : false;
        
        return $output;
    }
} 