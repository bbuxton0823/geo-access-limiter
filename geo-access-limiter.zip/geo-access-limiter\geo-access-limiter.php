<?php
/**
 * Plugin Name: Geo Access Limiter
 * Description: Restricts access to the WordPress site based on user's geographical location using AI and API.
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: geo-access-limiter
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Define plugin constants
define('GEO_ACCESS_LIMITER_VERSION', '1.0.0');
define('GEO_ACCESS_LIMITER_PATH', plugin_dir_path(__FILE__));
define('GEO_ACCESS_LIMITER_URL', plugin_dir_url(__FILE__));

// Include the core class responsible for loading all necessary components
require_once GEO_ACCESS_LIMITER_PATH . 'includes/class-geo-access-limiter.php';

// Activate and deactivate hooks
register_activation_hook(__FILE__, 'geo_access_limiter_activate');
register_deactivation_hook(__FILE__, 'geo_access_limiter_deactivate');

/**
 * Activation function
 */
function geo_access_limiter_activate() {
    // Add option for storing settings
    add_option('geo_access_limiter_settings', array(
        'api_key' => '',
        'allowed_locations' => array(),
        'restriction_message' => 'Sorry, this site is not available in your region.',
        'is_enabled' => false
    ));
}

/**
 * Deactivation function
 */
function geo_access_limiter_deactivate() {
    // Clean up if needed
}

/**
 * Start the plugin
 */
function run_geo_access_limiter() {
    $plugin = new Geo_Access_Limiter();
    $plugin->run();
}
run_geo_access_limiter(); 