/**
 * Geo Access Limiter JavaScript
 * 
 * Handles browser-based geolocation detection as a fallback/supplement
 * to the server-side IP-based detection.
 */
(function($) {
    'use strict';

    /**
     * Initialize the geolocation functionality
     */
    function initGeoAccessLimiter() {
        // Check if geolocation is available in the browser
        if (navigator.geolocation) {
            // Get the user's position
            navigator.geolocation.getCurrentPosition(
                handlePositionSuccess, 
                handlePositionError, 
                { 
                    enableHighAccuracy: true,
                    timeout: 5000,
                    maximumAge: 0
                }
            );
        }
    }

    /**
     * Handle successful geolocation
     * 
     * @param {Object} position The position object returned by the geolocation API
     */
    function handlePositionSuccess(position) {
        // Send the coordinates to the server for verification
        $.ajax({
            url: geoAccessLimiter.ajax_url,
            type: 'POST',
            data: {
                action: 'geo_check_location',
                nonce: geoAccessLimiter.nonce,
                latitude: position.coords.latitude,
                longitude: position.coords.longitude
            },
            success: function(response) {
                if (response.success) {
                    console.log('Location verification completed');
                } else {
                    console.error('Location verification failed:', response.data);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX request failed:', error);
            }
        });
    }

    /**
     * Handle geolocation errors
     * 
     * @param {Object} error The error object
     */
    function handlePositionError(error) {
        // Log the error but don't block access - we're using server-side verification as the main method
        let errorMessage;
        
        switch(error.code) {
            case error.PERMISSION_DENIED:
                errorMessage = 'User denied the request for geolocation.';
                break;
            case error.POSITION_UNAVAILABLE:
                errorMessage = 'Location information is unavailable.';
                break;
            case error.TIMEOUT:
                errorMessage = 'The request to get user location timed out.';
                break;
            case error.UNKNOWN_ERROR:
                errorMessage = 'An unknown error occurred.';
                break;
        }
        
        console.warn('Geolocation error:', errorMessage);
    }

    // Initialize when the DOM is fully loaded
    $(document).ready(function() {
        initGeoAccessLimiter();
    });

})(jQuery); 