<?php
/**
 * The public-facing functionality of the plugin.
 */
class Geo_Access_Limiter_Public {

    /**
     * The plugin settings.
     *
     * @var array
     */
    private $settings;

    /**
     * The API handler instance.
     *
     * @var Geo_Access_Limiter_API
     */
    private $api;

    /**
     * Initialize the class.
     *
     * @param array $settings Plugin settings.
     * @param Geo_Access_Limiter_API $api API handler.
     */
    public function __construct($settings, $api) {
        $this->settings = $settings;
        $this->api = $api;

        // Register the JavaScript for location detection
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // Add AJAX handler for location data
        add_action('wp_ajax_geo_check_location', array($this, 'ajax_check_location'));
        add_action('wp_ajax_nopriv_geo_check_location', array($this, 'ajax_check_location'));
    }

    /**
     * Register the JavaScript for the public area.
     */
    public function enqueue_scripts() {
        // Enqueue the main script
        wp_enqueue_script(
            'geo-access-limiter', 
            GEO_ACCESS_LIMITER_URL . 'public/js/geo-access-limiter.js', 
            array('jquery'), 
            GEO_ACCESS_LIMITER_VERSION, 
            true
        );
        
        // Enqueue the CSS
        wp_enqueue_style(
            'geo-access-limiter',
            GEO_ACCESS_LIMITER_URL . 'public/css/geo-access-limiter.css',
            array(),
            GEO_ACCESS_LIMITER_VERSION
        );
        
        // Pass data to script
        wp_localize_script(
            'geo-access-limiter',
            'geoAccessLimiter',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('geo_access_check')
            )
        );
    }

    /**
     * Check user location on page load
     */
    public function check_user_location() {
        // Skip for admin users
        if (current_user_can('manage_options')) {
            return;
        }
        
        // Get user location from API
        $location_data = $this->api->get_user_location();
        
        // If there was an error, log it and allow access
        if (is_wp_error($location_data)) {
            error_log('Geo Access Limiter Error: ' . $location_data->get_error_message());
            return;
        }
        
        // Check if location is allowed
        if (!$this->api->is_location_allowed($location_data)) {
            // Get custom message or use default
            $message = isset($this->settings['restriction_message']) ? 
                        $this->settings['restriction_message'] : 
                        'Sorry, this site is not available in your region.';
            
            // Display access denied page
            $this->display_access_denied($message);
            exit;
        }
    }
    
    /**
     * AJAX handler for checking location from browser
     */
    public function ajax_check_location() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'geo_access_check')) {
            wp_send_json_error('Invalid security token');
        }
        
        // Get coordinates from request
        $latitude = isset($_POST['latitude']) ? floatval($_POST['latitude']) : 0;
        $longitude = isset($_POST['longitude']) ? floatval($_POST['longitude']) : 0;
        
        if ($latitude == 0 && $longitude == 0) {
            wp_send_json_error('Invalid location data');
        }
        
        // In a real implementation, you would use these coordinates to check if the location is allowed
        // For now, we'll just return success since we're already checking via IP
        wp_send_json_success('Location check successful');
    }
    
    /**
     * Display access denied page
     *
     * @param string $message The message to display
     */
    private function display_access_denied($message) {
        // Remove all actions from wp_head and wp_footer
        remove_all_actions('wp_head');
        remove_all_actions('wp_footer');
        
        // Output a simple HTML page
        header('HTTP/1.1 403 Forbidden');
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="<?php bloginfo('charset'); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title><?php _e('Access Denied', 'geo-access-limiter'); ?></title>
            <style>
                body {
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
                    background-color: #f1f1f1;
                    margin: 0;
                    padding: 0;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                }
            </style>
            <!-- Load plugin CSS -->
            <link rel="stylesheet" href="<?php echo GEO_ACCESS_LIMITER_URL . 'public/css/geo-access-limiter.css'; ?>">
        </head>
        <body>
            <div class="geo-access-error-container">
                <h1 class="geo-access-error-title"><?php _e('Access Denied', 'geo-access-limiter'); ?></h1>
                <p class="geo-access-error-message"><?php echo esc_html($message); ?></p>
            </div>
        </body>
        </html>
        <?php
    }
} 