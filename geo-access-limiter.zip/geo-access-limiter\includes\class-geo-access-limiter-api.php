<?php
/**
 * Class for handling API interactions for geolocation
 */
class Geo_Access_Limiter_API {

    /**
     * Get user location data using IP-based geolocation
     * 
     * @return array|WP_Error Location data or error
     */
    public function get_user_location() {
        // Get user IP
        $user_ip = $this->get_user_ip();
        
        // Get settings
        $settings = get_option('geo_access_limiter_settings', array());
        $api_key = isset($settings['api_key']) ? $settings['api_key'] : '';
        
        if (empty($api_key)) {
            return new WP_Error('missing_api_key', 'API key is not configured');
        }
        
        // Use ipinfo.io API for geolocation (you can replace with any preferred API)
        $api_url = "https://ipinfo.io/{$user_ip}/json?token={$api_key}";
        
        $response = wp_remote_get($api_url);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['error'])) {
            return new WP_Error('api_error', $data['error']['message']);
        }
        
        return $data;
    }
    
    /**
     * Get the user's IP address
     * 
     * @return string User's IP address
     */
    private function get_user_ip() {
        // Check for proxy
        $ip = isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : '';
        
        if (empty($ip) && isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        }
        
        if (empty($ip)) {
            $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
        }
        
        return sanitize_text_field($ip);
    }
    
    /**
     * Check if location is allowed based on plugin settings
     * 
     * @param array $location_data Location data from API
     * @return bool Whether location is allowed
     */
    public function is_location_allowed($location_data) {
        $settings = get_option('geo_access_limiter_settings', array());
        $allowed_locations = isset($settings['allowed_locations']) ? $settings['allowed_locations'] : array();
        
        // If no locations are configured, allow access by default
        if (empty($allowed_locations)) {
            return true;
        }
        
        // Check if current location is in allowed locations
        if (isset($location_data['country'])) {
            return in_array($location_data['country'], $allowed_locations);
        }
        
        // If we can't determine location, allow access by default
        return true;
    }
} 