<?php
/**
 * The main plugin class
 */
class Geo_Access_Limiter {

    /**
     * Plugin settings array
     */
    protected $settings;

    /**
     * Initialize the class
     */
    public function __construct() {
        $this->settings = get_option('geo_access_limiter_settings', array());
        $this->load_dependencies();
    }

    /**
     * Load the required dependencies for this plugin.
     */
    private function load_dependencies() {
        // Admin area class
        require_once GEO_ACCESS_LIMITER_PATH . 'admin/class-geo-access-limiter-admin.php';
        
        // Public area class
        require_once GEO_ACCESS_LIMITER_PATH . 'public/class-geo-access-limiter-public.php';
        
        // API handler class
        require_once GEO_ACCESS_LIMITER_PATH . 'includes/class-geo-access-limiter-api.php';
    }

    /**
     * Execute the plugin by registering all the hooks
     */
    public function run() {
        // Only proceed if the plugin is enabled in settings
        if (isset($this->settings['is_enabled']) && $this->settings['is_enabled']) {
            // Initialize the API handler
            $api_handler = new Geo_Access_Limiter_API();
            
            // Initialize the public-facing functionality
            $plugin_public = new Geo_Access_Limiter_Public($this->settings, $api_handler);
            
            // Hook to check location before the page loads
            add_action('template_redirect', array($plugin_public, 'check_user_location'));
        }
        
        // Always initialize admin functionality regardless of whether the plugin is enabled
        $plugin_admin = new Geo_Access_Limiter_Admin($this->settings);
        
        // Add admin menu
        add_action('admin_menu', array($plugin_admin, 'add_plugin_admin_menu'));
        
        // Register settings
        add_action('admin_init', array($plugin_admin, 'register_settings'));
    }
} 